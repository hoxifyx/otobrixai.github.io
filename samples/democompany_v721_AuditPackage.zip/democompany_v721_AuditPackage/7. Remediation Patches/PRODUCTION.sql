-- Example RLS pattern (adapt to your schema) - API Key Owner Isolation

ALTER TABLE public.user_api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "api_keys_owner_only"
ON public.user_api_keys FOR ALL
USING ("userId" = auth.uid())
WITH CHECK ("userId" = auth.uid());

-- IMPORTANT: After applying this policy, force-rotate all existing keys.
-- You cannot know whether keys were already exfiltrated before this fix.