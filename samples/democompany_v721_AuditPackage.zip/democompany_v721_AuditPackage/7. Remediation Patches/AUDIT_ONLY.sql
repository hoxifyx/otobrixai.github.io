-- Example RLS pattern (adapt to your schema) - OAuth Session Isolation
-- Prevents cross-user token access. Do not apply directly to production. Test in staging before production deployment.

ALTER TABLE public.oauth_access_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.oauth_refresh_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "oauth_tokens_owner_only"
ON public.oauth_access_tokens FOR ALL
USING ("userId" = auth.uid())
WITH CHECK ("userId" = auth.uid());

CREATE POLICY "oauth_refresh_owner_only"
ON public.oauth_refresh_tokens FOR ALL
USING ("userId" = auth.uid())
WITH CHECK ("userId" = auth.uid());