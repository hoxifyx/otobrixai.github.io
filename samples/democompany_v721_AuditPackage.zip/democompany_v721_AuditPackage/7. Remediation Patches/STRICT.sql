-- Example RLS pattern (adapt to your schema) - Credential Vault Isolation
-- Do not apply directly to production. Test in staging before production deployment.

ALTER TABLE public.credentials_entity ENABLE ROW LEVEL SECURITY;

CREATE POLICY "credentials_owner_only"
ON public.credentials_entity FOR ALL
USING (
    "projectId" IN (
        SELECT id FROM public.project
        WHERE "ownedById" = auth.uid()
        OR id IN (
            SELECT "projectId" FROM public.shared_workflow
            WHERE "userId" = auth.uid()
        )
    )
)
WITH CHECK (
    "projectId" IN (
        SELECT id FROM public.project
        WHERE "ownedById" = auth.uid()
    )
);

-- VERIFY: After applying, a Trial user's API call should return 0 rows.